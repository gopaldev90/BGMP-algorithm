import java.io.*;
import java.util.*;
import com.google.gson.*;
import java.nio.file.*;
import java.lang.Math;

public class Extendlist {

	// Check if a number is prime
	public static boolean isPrime(int n) {
		if (n < 2) {
			return false;
		}
		int limit = (int) Math.sqrt(n);
		for (int i = 2; i <= limit; i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}

	// Get the next 'n' prime numbers starting from 'start'
	public static List<String> getPrimes(int n, int start) {
		List<String> primes = new ArrayList<>();
		int found = 0;
		int i = start;

		while (found < n) {
			if (isPrime(i)) {
				primes.add(String.valueOf(i));
				found++;
			}
			i++;
		}

		return primes;
	}

	// Load JSON data from a file using Gson
	public static JsonObject loadJson(String path) throws IOException {
		Reader reader = Files.newBufferedReader(Paths.get(path));
		return JsonParser.parseReader(reader).getAsJsonObject();
	}

	// Save JSON data to a file using Gson
	public static void saveJson(Map<String, Object> data, String path) throws IOException {
        Writer writer = Files.newBufferedWriter(Paths.get(path));
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        gson.toJson(data, writer);
        writer.close();
    }
    

	public static void main(String[] args, Map<String, Object> data) throws IOException {
		// Get the current prime numbers from the JSON data
		try {

			@SuppressWarnings("unchecked")
			ArrayList<Object> primeArray = (ArrayList<Object>) data.get("abhajy");
			String abhaj=String.valueOf(primeArray.get(primeArray.size()-1));
			int lastPrime= Integer.parseInt((abhaj.split("\\.")[0]));
			int start = lastPrime + 1;
			System.out.println("Start from: " + start);
			Scanner scanner = new Scanner(System.in);
			System.out.print("katte: ");
			int count = scanner.nextInt();
			List<String> newPrimes = getPrimes(count, start);
			System.out.println(newPrimes);
			for (String prime : newPrimes) {
				primeArray.add(prime);
			}
			saveJson(data, Main.datapath);
			System.out.println("Number of new primes found: " + newPrimes.size());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
