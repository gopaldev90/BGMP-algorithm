import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.io.*;
import java.util.List;
import java.util.Scanner;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;

public class Main {
	public static Map<Integer, int[]> mersenneMap = new HashMap<>();
	public static ArrayList<BigInteger> abhajyList = new ArrayList<>();
	public static Gson gson = new Gson();
	public static File file;
	public static String datapath;
	public static Map<String, Object> data;
	public static final BigInteger solaah = BigInteger.valueOf(16);
	static {
		
		try {
			System.out.println("cwd= " + System.getProperty("user.dir", null));
			file = new File("data.json");
			if(!file.exists()) {
				datapath = "src" + File.separator + "main" + File.separator + "java" + File.separator
						   + "data.json";
				file = new File(datapath);
			}
			FileReader reader = new FileReader(file);
			data = gson.fromJson(reader, new TypeToken<Map<String, Object>>() {
			} .getType());
			reader.close();
			mersenneMap = loadMersenneMap();
			abhajyList = loadSmallPrimes();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public static ArrayList<BigInteger> loadSmallPrimes() {

		ArrayList<Object> floatPrimes = (ArrayList<Object>) data.get("abhajy");
		ArrayList<BigInteger> integerPrimes = new ArrayList<>();
		for (Object prime : floatPrimes) {
			String strnum = String.valueOf(prime);
			if(strnum.contains(".")) {
				strnum = strnum.split("\\.")[0];
			}
			BigInteger intnum = new BigInteger(strnum);
			integerPrimes.add(intnum);
		}
		return integerPrimes;
	}

	@SuppressWarnings("unchecked")
	public static Map<Integer, int[]> loadMersenneMap() {
		Object mersannObj = data.get("poorvmarsnwbhajy");

		Map<String, String> mersann = (Map<String, String>) mersannObj;
		Map<Integer, int[]> merMap = new HashMap<>();

		for (Map.Entry<String, String> entry : mersann.entrySet()) {
			int key = Integer.parseInt(entry.getKey());
			String val = entry.getValue();
			String[] parts = val.split(",");
			int[] intArray = new int[2];
			for (int i = 0; i < parts.length; i++) {
				intArray[i] = Integer.parseInt(parts[i]);
			}
			merMap.put(key, intArray);
		}

		return merMap;

	}

	public static String getPrefixFValue(int n) {
		int[] result = mersenneMap.get(n);
		if(result != null) {
			return result[0] + "," + result[1];
		} else {
			return "Not found";
		}

	}

	public static boolean haibhajy(BigInteger n, int sambhav) {

		return isValidPrimeCandidate(n) && n.isProbablePrime(sambhav);
	}

	public static boolean isValidPrimeCandidate(BigInteger num) {

		for (BigInteger prime : abhajyList) {

			if((!num.equals(prime)) && (num.mod(prime).equals(BigInteger.ZERO))) {
				System.out.println("saste main nipat gya: " + prime);
				return false;
			}
		}
		System.out.println("mahenga padega");
		return true;
	}

	public static void getln(BigInteger n) {
		int digits = (int) Math.floor(n.bitLength() * Math.log10(2)) + 1;

		System.out.println("Number of digits: " + digits);
	}

	public static boolean isPrime(BigInteger n) {
		Boolean parin;
		Boolean alas = true;
		// getln(n);
		if(!alas) {
			parin = haibhajy(n, 13);
		} else {
			try {
				int p = logbase2(n.add(BigInteger.ONE));
				System.out.println("p=" + p);
				parin = (haibhajy(BigInteger.valueOf(p), 20) && lucasLehmerTest(p, n));
			} catch (IllegalArgumentException e) {
				System.out.println(e.getMessage());
				parin = false;
			}
		}
		System.out.println("parinaam:" + parin);
		return parin;
	}

	public static int logbase2(BigInteger value) {
		
		if(!isPowerOfTwo(value)) {
			throw new IllegalArgumentException("Value is not a power of 2.");
		}
		return value.bitLength() - 1;
	}

	public static boolean isPowerOfTwo(BigInteger value) {
		return value.and(value.subtract(BigInteger.ONE)).equals(BigInteger.ZERO);
	}

	public static boolean lucasLehmerTest(int p, BigInteger M_p) {
		BigInteger s = BigInteger.valueOf(4);
		// s = (s * s - 2) % M_p
		for (int c = 0; c < p - 2; c++) {
			// bohot mahengaa
			s = s.multiply(s);
			s = s.subtract(BigInteger.TWO);
			s = s.mod(M_p);
			//System.out.println((c + 1) + " chakker");
		}
		// If the result is 0, M_p is prime
		return s.equals(BigInteger.ZERO);
	}

	public static void saveFile(int n, String data) {
		n = Integer.parseInt(String.valueOf(n));
		String path = "Mersenne prime.txt";
		File file = new File(path);
		if(file.getParentFile() != null) {
			file.getParentFile().mkdirs();
		}
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) { // 'true' for append mode
			writer.write(n + " vaan Mersenne prime number \n");
			writer.write(data);
			writer.newLine();
			System.out.println("Jankary likhi gyi Safaltapoorvak.");
		} catch (IOException e) {
			System.err.println("An error occurred while writing to the file: " + e.getMessage());
		}
	}

	public static int lastmeessen() {
		int max = 0;
		String result;
		while (true) {
			result = getPrefixFValue(max + 1);
			if(result.equals("Not found")) {
				break;
			}
			max++;
		}
		return max;
	}

	public static BigInteger fastPower(BigInteger adhaar, long exp) {
		BigInteger result = BigInteger.ONE;
		BigInteger power = adhaar;

		while (exp > 0) {
			if(exp % 2 == 1) {
				result = result.multiply(power);
			}
			power = power.multiply(power);
			exp /= 2;
		}

		return result;
	}

	public static BigInteger creatmersan(String option, BigInteger power) {
		BigInteger mers;
		
		if(option.equals("1")) {
			mers = power.multiply(BigInteger.valueOf(2)).subtract(BigInteger.ONE);
			// 2 * 16^fcount - 1
		} else if(option.equals("7")) {
			mers = power.multiply(BigInteger.valueOf(7)).add(power.subtract(BigInteger.ONE));
			// 7 * 16^fcount + (16^fcount - 1)
		} else {
			throw new ArithmeticException("invalid prefix");
		}
		return mers;
	}

	@SuppressWarnings("unused")
	public static String getmersn(int n) {

		String[] op = { "1", "7" };
		String result;
		BigInteger num;
		int maxn = lastmeessen();
		int banne = 0;
		long fCount = 0;
		long jarirak = 34069967;
		boolean debug = 0 != 0;
		int mapsenik = 0;
		BigInteger power = fastPower(solaah, fCount);
		String mersen = "Error";
		if(debug) {
			maxn = 7;
			String par = getPrefixFValue(maxn);
			String[] parts = par.split(",");
			jarirak = (Long.parseLong(parts[1]));
			// jarirak = 2785;
		}
		while (banne < n) {
			if(mapsenik < maxn) {
				// sari value map se lao
				result = getPrefixFValue(mapsenik + 1);
				String[] parts = result.split(",");
				banne++;
				mersen = result;
				System.out.println("Mila " + banne + ". " + result);
				mapsenik++;
				if(mapsenik == maxn) {
					fCount = jarirak;
					power = fastPower(solaah, fCount);
					
				}
			} else {
				// nayi value yahan bnao
				// n=(n*16)+15
				fCount += 1;
				power = power.multiply(solaah);
				for (String option : op) {
					num = creatmersan(option, power);
					System.out.println("abhajya janch rha " + (option + "," + fCount));
					if(isPrime(num)) {
						mersen = option + "," + fCount;
						banne++;
						System.out.println("bnaya " + banne + ". Found: " + option + " f: " + fCount);
						if(banne == n) {
							break;
						}
					}
				}

			}

		}
		return mersen;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("e). list bdha, m). merssen, d). do digit ganna, else). perfect number");
		String mode = sc.nextLine();
		if(mode.equals("m")) {
			System.out.println("kaunsa merssprime number?");
			int katte = sc.nextInt();
			long startTime = System.nanoTime();
			if(katte > 0) {
				String mrsn = getmersn(katte);
				System.out.println(mrsn);
				saveFile(katte, mrsn);
			}
			long endTime = System.nanoTime();
			long duration = (endTime - startTime) / 1_000_000;
			System.out.println("Time taken by the function: " + duration + " milliseconds");
		} else if(mode.equals("d")) {
			DedigitGanna.main(args);
		} else if(mode.equals("e")) {
			try {
				Extendlist.main(args, data);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else {
			Getperfectnumber.main(args);
		}

	}
}
