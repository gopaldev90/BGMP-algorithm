import java.util.Scanner;
public class DedigitGanna {
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
	    System.out.println("fCount ");
        long fCount = sc.nextLong();
        int base = 16;
        long numDigits =(long) Math.floor(fCount * Math.log10(base)) + 1;
        System.out.println(numDigits);
    }
}